# DLND - Project 1 - Bike Sharing Neural Network (First Neural Network)
Hyperparameters used here are chosen to avoid overfitting
iterations = 3000
learning_rate = 0.09
hidden_nodes = 12
output_nodes = 1

Output:
Training loss: 0.267 
Validation loss: 0.437